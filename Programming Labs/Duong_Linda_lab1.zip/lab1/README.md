Consult the Wiki Instructions on the repo.
