// JavaScript code goes here

var pokemonList = [];

pokemonList = [{
    "name": "Bulbasaur",
    "type": "Grass",
    "final_evolution": "Venusaur",
    "hp": 80,
    "attack_power": 82,
},
{
    "name": "Charmander",
    "type": "Fire",
    "final_evolution": "Charizard",
    "hp": 78,
    "attack_power": 84,
},
{
    "name": "Squirtle",
    "type": "Water",
    "final_evolution": "Blastoise",
    "hp": 79,
    "attack_power": 83,
}]

console.log(pokemonList);